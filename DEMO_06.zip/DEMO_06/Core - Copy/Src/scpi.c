#include "scpi.h"
#include "main.h"
#include <string.h>
#include <stdlib.h>

#define BUF_SIZE 50
static char line_buf[BUF_SIZE];
static uint16_t idx;
static UART_HandleTypeDef *hUART;

void SCPI_Init(UART_HandleTypeDef *huart)
{
    hUART = huart;
    idx = 0;
    memset(line_buf, 0, BUF_SIZE);
}

void SCPI_RxHandler(uint8_t b)
{
    if (b == '\r' || b == '\n')
    {
        if (idx > 0) line_buf[idx] = '\0';
        line_buf[BUF_SIZE-1] = '\n';
    }
    else
    {
        if (idx < BUF_SIZE-2) line_buf[idx++] = (char)b;
    }
}

static void reply(char *s)
{
    HAL_UART_Transmit_IT(hUART, (uint8_t *)s, strlen(s));
}

void SCPI_Process(void)
{
    if (line_buf[BUF_SIZE-1] != '\n') return;
    char cmd[BUF_SIZE];
    strncpy(cmd, line_buf, idx + 1);
    cmd[idx] = '\0';
    idx = 0;
    line_buf[0] = '\0';
    line_buf[BUF_SIZE-1] = '\0';

    char *token = strtok(cmd, " \t");
    if (!token) return;

    if (strcmp(token, "*IDN?") == 0)
    {
       // reply("FEVAT,POWER SUPPLY 60V 100Amp,v0.001,25-04-2025\r\n");
    	reply("SIGLENT, SPD5000X POWER SUPPLY 60V 100Amp,v0.001,25-04-2025\r\n");

    }
    else if (strcmp(token, "Volt(V)") == 0)
    {
        char *arg = strtok(NULL, " ");
        if (arg)
        {

            reply("OK VOLTAGE SET SUCCESS \r\n");
            //  wroite code to perform any power supply


        }
        else
        {
            reply("?CMD,Missing voltage\r\n");
        }
    }
    else if (strcmp(token, "Current(A)") == 0)
    {
        char *arg = strtok(NULL, " ");
        if (arg)
        {
           // float i = strtof(arg, NULL);
        	 reply("OK CURRENT SET SUCCESS \r\n");
        }
        else
        {
            reply("?CMD,Missing current\r\n");
        }
    }
    else if (strcmp(token, "OUT") == 0)
    {
        char *arg = strtok(NULL, " ");
        if (arg)
        {
            if (strcmp(arg, "ON") == 0)
            {  // NVIC_SystemReset();
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
                reply("OK LED  ON \n");
            }
            else if (strcmp(arg, "OFF") == 0)
            {
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_13, GPIO_PIN_SET);
                reply("OK LED OFF \n");
            }
            else
            {
                reply("?CMD,Invalid state\r\n");
            }



        }
        else
        {
            reply("?CMD,Missing state\r\n");
        }
    }
    else if (strcmp(token, "RESET") == 0)
    {

        NVIC_SystemReset();
        reply(" RESET SUCCESSFULLY \r\n");
        reply("SIGLENT, SPD5000X POWER SUPPLY 60V 100Amp,v0.001,25-04-2025\r\n");
    }
    else
    {
        reply("?CMD,Unknown command\r\n");
    }


}
