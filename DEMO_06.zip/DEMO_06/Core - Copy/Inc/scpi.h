/*
 * SCPI.h
 *
 *  Created on: Apr 25, 2025
 *      Author: dev
 */

#ifndef INC_SCPI_H_
#define INC_SCPI_H_

#include "stm32f1xx_hal.h"

void SCPI_Init(UART_HandleTypeDef *huart);
void SCPI_RxHandler(uint8_t b);
void SCPI_Process(void);
//void reply(char *s);



#endif /* INC_SCPI_H_ */
