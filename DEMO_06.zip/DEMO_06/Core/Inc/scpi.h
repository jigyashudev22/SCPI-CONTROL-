
//--------------------------------------- version v0.1-------------------------------------
#ifndef __SCPI_H
#define __SCPI_H

#include "stm32f1xx_hal.h"

void SCPI_Init(UART_HandleTypeDef *huart);
void SCPI_RxHandler(uint8_t byte);
void SCPI_Process(const char *cmd_line);

#endif /* __SCPI_H */


//
////--------------------------------------- version v0.2-------------------------------------
//#ifndef INC_SCPI_H_
//#define INC_SCPI_H_
//
//#include "stm32f1xx_hal.h"
//#include <stdbool.h>
//
//#define SCPI_CMD_MAX_LEN 100
//#define SCPI_QUEUE_DEPTH 10
//
//// External flag to pause/resume main loop transmission
//extern volatile bool scpi_active;
//
//// Initialization
//void SCPI_Init(UART_HandleTypeDef *huart);
//
//// Feed incoming byte to SCPI parser
//void SCPI_RxHandler(uint8_t byte);
//
//// Process one command from the queue (call from main loop)
//void SCPI_ProcessQueue(void);
//
//#endif /* INC_SCPI_H_ */
//
