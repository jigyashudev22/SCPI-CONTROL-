//--------------------------------------- version v0.1-------------------------------------
#include "scpi.h"
#include "main.h"
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define BUF_SIZE 100
static char line_buf[BUF_SIZE];
static uint16_t idx;
static UART_HandleTypeDef *hUART;
extern volatile bool scpi_active;

typedef enum {
    CMD_IDN,
    CMD_VOLT,
    CMD_CURR,
    CMD_OUT,
    CMD_RESET,
    CMD_UNKNOWN
} SCPI_Command;

void SCPI_Init(UART_HandleTypeDef *huart)
{
    hUART = huart;
    idx = 0;
    memset(line_buf, 0, BUF_SIZE);
}

void SCPI_RxHandler(uint8_t b)
{
    if (b == '\r' || b == '\n')
    {
        if (idx > 0) {
            line_buf[idx] = '\0';
            SCPI_Process(line_buf);
            idx = 0;
            memset(line_buf, 0, BUF_SIZE);
        }
    }
    else if (idx < BUF_SIZE - 1)
    {
        line_buf[idx++] = (char)b;
    }
}

static void reply(const char *s)
{
    HAL_UART_Transmit_IT(hUART, (uint8_t *)s, strlen(s));
}

static SCPI_Command parse_command(const char *token)
{
    if (strcmp(token, "*IDN?") == 0) return CMD_IDN;
    if (strcmp(token, "Volt(V)") == 0) return CMD_VOLT;
    if (strcmp(token, "Current(A)") == 0) return CMD_CURR;
    if (strcmp(token, "OUT") == 0) return CMD_OUT;
    if (strcmp(token, "RESET") == 0) return CMD_RESET;
    return CMD_UNKNOWN;
}

void SCPI_Process(const char *cmd_line)
{
    char cmd[BUF_SIZE];
    strncpy(cmd, cmd_line, BUF_SIZE - 1);
    cmd[BUF_SIZE - 1] = '\0';

    char *token = strtok(cmd, " \t");
    if (!token) {
        scpi_active = false;
        return;
    }

    SCPI_Command command = parse_command(token);

    switch (command)
    {
        case CMD_IDN:
//            reply("FEVAT,PS\r\n");
//        	reply("SIGLENT, SPD5000X 60V 100Amp,v0.001,2025\r\n");
        	reply("Kikusui, Kikusui Electronics 60V 100Amp,v0.001,2025\r\n");
            scpi_active=1;
            break;

        case CMD_VOLT: {
            char *arg = strtok(NULL, " ");
            reply(arg ? "OK VOLTAGE SET SUCCESS\r\n" : "?CMD,Missing voltage\r\n");
            break;
        }

        case CMD_CURR: {
            char *arg = strtok(NULL, " ");
            reply(arg ? "OK CURRENT SET SUCCESS\r\n" : "?CMD,Missing current\r\n");
            break;
        }

        case CMD_OUT: {
            char *arg = strtok(NULL, " ");
            if (arg) {
                if (strcmp(arg, "ON") == 0) {
                    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
                    reply("OK LED ON\r\n");
                } else if (strcmp(arg, "OFF") == 0) {
                    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_13, GPIO_PIN_SET);
                    reply("OK LED OFF\r\n");
                } else {
                    reply("?CMD,Invalid state\r\n");
                }
            } else {
                reply("?CMD,Missing state\r\n");
            }
            break;
        }

        case CMD_RESET:
            reply("RESET SUCCESSFULLY\r\n");
            reply("SIGLENT, SPD5000X POWER SUPPLY 60V 100Amp,v0.001,25-04-2025\r\n");
            NVIC_SystemReset();
            break;

        case CMD_UNKNOWN:
        default:
            reply("?CMD,Unknown command\r\n");
            break;
    }

    scpi_active = false;
}
//
//
//
////--------------------------------------- version v0.2-------------------------------------
//#include "scpi.h"
//#include "main.h"
//#include <string.h>
//#include <stdlib.h>
//
//typedef enum {
//    CMD_IDN,
//    CMD_VOLT,
//    CMD_CURR,
//    CMD_OUT,
//    CMD_RESET,
//    CMD_UNKNOWN
//} SCPI_Command;
//
//typedef struct {
//    char commands[SCPI_QUEUE_DEPTH][SCPI_CMD_MAX_LEN];
//    uint8_t head;
//    uint8_t tail;
//    uint8_t count;
//} SCPI_Queue;
//
//static SCPI_Queue scpi_queue;
//static char line_buf[SCPI_CMD_MAX_LEN];
//static uint16_t idx = 0;
//static UART_HandleTypeDef *hUART;
//volatile bool scpi_active = false;
//
//static void reply(const char *s)
//{
//    HAL_UART_Transmit_IT(hUART, (uint8_t *)s, strlen(s));
//}
//
//void SCPI_Init(UART_HandleTypeDef *huart)
//{
//    hUART = huart;
//    idx = 0;
//    memset(line_buf, 0, sizeof(line_buf));
//    memset(&scpi_queue, 0, sizeof(scpi_queue));
//}
//
//bool SCPI_Enqueue(const char *cmd)
//{
//    if (scpi_queue.count >= SCPI_QUEUE_DEPTH) return false;
//
//    strncpy(scpi_queue.commands[scpi_queue.tail], cmd, SCPI_CMD_MAX_LEN - 1);
//    scpi_queue.commands[scpi_queue.tail][SCPI_CMD_MAX_LEN - 1] = '\0';
//    scpi_queue.tail = (scpi_queue.tail + 1) % SCPI_QUEUE_DEPTH;
//    scpi_queue.count++;
//    return true;
//}
//
//void SCPI_RxHandler(uint8_t b)
//{
//    if (b == '\r' || b == '\n')
//    {
//        if (idx > 0)
//        {
//            line_buf[idx] = '\0';
//            SCPI_Enqueue(line_buf);
//            idx = 0;
//            memset(line_buf, 0, sizeof(line_buf));
//            scpi_active = true;
//        }
//    }
//    else if (idx < SCPI_CMD_MAX_LEN - 1)
//    {
//        line_buf[idx++] = (char)b;
//    }
//}
//
//static SCPI_Command parse_command(const char *token)
//{
//    if (strcmp(token, "*IDN?") == 0) return CMD_IDN;
//    if (strcmp(token, "Volt(V)") == 0) return CMD_VOLT;
//    if (strcmp(token, "Current(A)") == 0) return CMD_CURR;
//    if (strcmp(token, "OUT") == 0) return CMD_OUT;
//    if (strcmp(token, "RESET") == 0) return CMD_RESET;
//    return CMD_UNKNOWN;
//}
//
//static void SCPI_Execute(const char *cmd_line)
//{
//    char cmd[SCPI_CMD_MAX_LEN];
//    strncpy(cmd, cmd_line, SCPI_CMD_MAX_LEN - 1);
//    cmd[SCPI_CMD_MAX_LEN - 1] = '\0';
//
//    char *token = strtok(cmd, " \t");
//    if (!token) return;
//
//    SCPI_Command command = parse_command(token);
//
//    switch (command)
//    {
//        case CMD_IDN:
//            reply("FEVAT,PS\r\n");
//            break;
//
//        case CMD_VOLT: {
//            char *arg = strtok(NULL, " ");
//            reply(arg ? "OK VOLTAGE SET SUCCESS\r\n" : "?CMD,Missing voltage\r\n");
//            break;
//        }
//
//        case CMD_CURR: {
//            char *arg = strtok(NULL, " ");
//            reply(arg ? "OK CURRENT SET SUCCESS\r\n" : "?CMD,Missing current\r\n");
//            break;
//        }
//
//        case CMD_OUT: {
//            char *arg = strtok(NULL, " ");
//            if (arg) {
//                if (strcmp(arg, "ON") == 0) {
//                    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
//                    reply("OK LED ON\r\n");
//                } else if (strcmp(arg, "OFF") == 0) {
//                    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_13, GPIO_PIN_SET);
//                    reply("OK LED OFF\r\n");
//                } else {
//                    reply("?CMD,Invalid state\r\n");
//                }
//            } else {
//                reply("?CMD,Missing state\r\n");
//            }
//            break;
//        }
//
//        case CMD_RESET:
//            reply("RESET SUCCESSFULLY\r\n");
//            reply("SIGLENT, SPD5000X POWER SUPPLY 60V 100Amp,v0.001,25-04-2025\r\n");
//            NVIC_SystemReset();
//            break;
//
//        case CMD_UNKNOWN:
//        default:
//            reply("?CMD,Unknown command\r\n");
//            break;
//    }
//}
//
//void SCPI_ProcessQueue(void)
//{
//    if (scpi_queue.count == 0) {
//        scpi_active = false;
//        return;
//    }
//
//    const char *cmd = scpi_queue.commands[scpi_queue.head];
//    SCPI_Execute(cmd);
//
//    scpi_queue.head = (scpi_queue.head + 1) % SCPI_QUEUE_DEPTH;
//    scpi_queue.count--;
//
//    if (scpi_queue.count == 0) {
//        scpi_active = false;
//    }
//}
//
//
